<?php get_header(); ?>

<?php get_sidebar(); ?>

<?php get_template_part('right-sidebar'); ?>

<div id="content">

	<div class="page">

		<h2 class="center"><?php _e('Error 404 - Not Found','wp-andreas225') ?></h2>

	</div>

</div>



<?php get_footer(); ?>


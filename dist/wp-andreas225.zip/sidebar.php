<div id="leftside">
    <ul>

    <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Main Sidebar') ) : else : ?>

        <li>Main Sidebar</li>

    <?php endif; ?>

    </ul>
</div>












</div>

<div class="clearingdiv">&nbsp;</div>

</div>



<div id="footer">



<a href="<?php echo esc_url( home_url() ); ?>/"><?php bloginfo('name'); ?></a> <?php _e('is powered by','wp-andreas225'); ?> <a href="http://wordpress.org/">WordPress</a> | 

<?php _e('Design by','wp-andreas225'); ?> <a href="http://andreasviklund.com">Andreas Viklund</a> | 

<?php _e('Ported by','wp-andreas225'); ?> <a href="http://webgazette.co.uk">Ainslie Johnson</a>  

<?php _e('<!-- | xyz translation by <a href="your url">your name</a> -->','wp-andreas225'); ?>



</div>



<?php wp_footer(); ?>



</body>



</html>